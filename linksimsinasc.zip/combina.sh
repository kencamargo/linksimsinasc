source ./projeto/bin/activate
python3 combina.py

